const wynik = document.querySelector(`#wynik`);
const btn = document.querySelector('button');

btn.addEventListener(`click`, function () {
        let a = document.querySelector(`#zmienna_a`).value.toLowerCase();
        let plec
        if (a.endsWith("a") && a!== "kuba" && a!=="barnaba")
                plec = "Kobieta"
        else
                plec = "Mężczyzna"
        wynik.innerHTML = `${plec}`;
    }
)